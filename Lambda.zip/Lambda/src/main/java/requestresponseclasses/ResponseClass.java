package requestresponseclasses;

public class ResponseClass {
    String greetings;

    public ResponseClass() {
    }

    public String getGreetings() {
        return greetings;
    }

    public void setGreetings(String greetings) {
        this.greetings = greetings;
    }

    public ResponseClass(String greetings) {
        this.greetings = greetings;
    }
}
