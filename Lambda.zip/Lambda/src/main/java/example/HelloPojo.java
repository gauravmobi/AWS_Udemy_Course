package example;

public class HelloPojo {

}
